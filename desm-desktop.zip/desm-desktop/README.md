# DESM Desktop (giai đoạn 1-2) — CHƯA build / CHƯA thử máy thật
Electron bọc web DESM, giữ đăng nhập 30 ngày, thanh địa chỉ, phóng to/thu nhỏ (Gốc = 100%), bong bóng chat Dodo (trích từ app iOS).
Build: đẩy lên GitHub -> tab Actions -> tải artifact DESM-Desktop-win (.exe cài đặt + portable).
Chạy thử: `npm install && npm start`.
Giai đoạn 2-5: màn Package (bảng, sắp xếp, xuất CSV, chi tiết, hạng mục chi tiết chọn nhiều, sửa Short/Over/DMG/Missing + Remarks của hạng mục, Location Update/Xoá vị trí, Material Confirm/Hủy xác nhận) — các lệnh ghi CHƯA thử trên dữ liệu thật, hãy thử kiện test. Customs Y/N bỏ qua (chỉ dự án Nga). Sau này: Edit Log, MIR/RFI, AI riêng.

Việt hoá: nút "VI" trên thanh địa chỉ (mặc định bật) dịch giao diện DESM bằng từ điển 161 mục của app iOS; bật/tắt sẽ tải lại trang. Dùng preload trong cả iframe (nodeintegrationinsubframes) — nếu iframe không được dịch, báo lại.
LƯU Ý: preload Electron bị sandbox nên mọi script nạp qua IPC (main.js), không dùng fs trong preload.

Giai đoạn 6 (giao diện PC): menu gốc Tệp/Xem/Công cụ/Trợ giúp có phím tắt (F5, Ctrl+1/2, Ctrl+K, Ctrl+E, Ctrl+L, Ctrl+D, Ctrl +/−/0, F11); nhớ kích thước/vị trí cửa sổ; chỉ mở 1 cửa sổ; thanh trạng thái dưới; menu chuột phải trên dòng; phím ↑/↓/Space/Ctrl+A trong bảng.
MIR/RFI: nút "MIR/RFI ▾" — kiểm tra điều kiện tạo phiếu, Chấp nhận, Hủy (check -> save theo plSummary.js). POPUP TẠO PHIẾU chưa hỗ trợ (chưa có mã nguồn popup) — tạo ở tab Trình duyệt DESM. Các lệnh ghi chưa thử thật.

Location Update hiện BẢN ĐỒ (ảnh MAP_PATH tải qua phiên đăng nhập + ô RECT/LINE trên khung 1200×700 như web); bấm vào ô để chọn, danh sách ô bên dưới vẫn dùng được; tự chọn lại bản đồ dùng gần nhất.

Bản 0.2.0 (độ tin cậy): phát hiện phiên hết hạn (banner "Đăng nhập lại", tự Search lại khi quay về tab Package); phân trang 200 dòng/trang; chế độ sáng/tối bằng bảng màu riêng (biến CSS, mặc định theo hệ điều hành); icon app (build/icon.png); installer đặt tên DESM-Desktop-Setup-<ver>.exe và bản Portable.
Ký số (tuỳ chọn, bỏ cảnh báo SmartScreen): cần chứng chỉ Code Signing, thêm CSC_LINK/CSC_KEY_PASSWORD vào GitHub Secrets rồi truyền vào bước "npm run dist" trong build.yml.

Bản 0.3.0 (tính năng): Xuất Excel .xlsx thật (Ctrl+E; tiêu đề đậm, cố định hàng đầu, bộ lọc tự động; theo cột đang hiện + thứ tự đang sắp xếp), Xuất CSV đổi sang Ctrl+Shift+E; nút "Cột ▾" chọn/ẩn 17 cột (nhớ cấu hình); kéo mép tiêu đề để đổi độ rộng cột; nút "Bộ lọc ▾" lưu/áp dụng/xoá bộ lọc tìm kiếm.
Chưa làm: popup tạo MIR/RFI (thiếu mã nguồn), AI riêng, quét RSI, tự cập nhật (cần kho phát hành), chế độ "Gọn" cho trang web gốc.

Bản 0.3.1: sửa lỗi bố cục — bảng nhiều dòng làm cả trang cuộn, thanh trạng thái/cột bên che dòng (grid không giới hạn chiều cao hàng). Nay bảng tự cuộn trong khung, thanh trạng thái luôn ở đáy cửa sổ.

Bản 0.3.2: làm đẹp giao diện — viền + bóng cho khung lọc/ô nhập/nút, vòng sáng khi focus, hover/nhấn cho nút, thanh công cụ dạng khung, tiêu đề cột in hoa, dòng xen kẽ + vạch xanh dòng đang chọn, thanh cuộn mảnh, placeholder cho ô tìm kiếm.

Bản 0.3.3: tăng độ nét — viền đậm 1px sắc cạnh (--bd-strong) cho ô tìm kiếm/nút/khung, bỏ bóng mờ và hiệu ứng làm nhoè; focus bằng viền xanh liền nét; làm mịn chữ.

Bản 0.3.4: làm lại panel chi tiết — đầu panel (số kiện, trạng thái, vị trí), 'Thông tin kiện' 2 cột, ô chênh lệch Short/Over/DMG/Missing (đỏ khi > 0), danh sách hạng mục dạng thẻ (Nhập/Xuất/Còn lại, vị trí, nhãn chênh lệch, nút Sửa/Edit Log), thanh công cụ hạng mục dính trên cùng khi cuộn. Panel rộng 380px.

Bản 0.3.5: khung tìm kiếm nổi bật — thanh lọc nền xanh nhạt viền xanh, ô nhập cao 42px viền 2px, biểu tượng riêng cho từng ô (Package No/PL/Mô tả/Vị trí), ô đã nhập tự đổi viền xanh đậm, nút Search lớn.

Bản 0.4.0 (đồng bộ giao diện): toàn bộ CSS gom về MỘT file renderer/style.css (token màu/cỡ/bo góc, sáng + tối) thay cho các lớp CSS chồng nhau; markup viết lại không còn style nội dòng (trừ độ rộng cột). Thêm: menu trái có logo + biểu tượng, thanh tiêu đề trang (Package · Dự án · trạng thái kết nối DESM), thanh công cụ chia nhóm có biểu tượng, hộp thoại thống nhất (tiêu đề / nội dung / chân nút, có nút X, bấm nền để đóng), dòng tích chọn tô màu, bảng/panel/menu cùng một bộ viền-bóng-bo góc.

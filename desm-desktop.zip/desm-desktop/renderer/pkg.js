// Màn Package (giai đoạn 2) — CHƯA kiểm chứng trên máy thật. Ghi vị trí theo API trong DEV_NOTES (saveDesmLocationCheck/saveDesmLocation/deleteDesmLocation).
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ALLCOLS = [['PACKAGE_NO', 'Package No', 130, 1], ['PACKAGE_LIST_NO', 'PL No', 100, 1], ['DESCRIPTION', 'Mô tả', 280, 1], ['PACKAGE_TYPE', 'Loại', 100, 1], ['OUT_STATUS_QTY', 'SL (tổng/đã xuất)', 130, 1], ['STORAGE_LOCATION', 'Location', 150, 1], ['PACKAGE_STATUS', 'Trạng thái', 120, 1],
  ['LOC_UPDATED_BY', 'Người cập nhật VT', 140, 0], ['LOC_UPDATE_DATE', 'Ngày cập nhật VT', 140, 0], ['CONFIRMED_BY', 'Người xác nhận', 130, 0], ['CONFIRM_DATE', 'Ngày xác nhận', 130, 0], ['L_CM', 'Dài (cm)', 90, 0], ['GROSS', 'Gross', 90, 0], ['VOLUME', 'Volume', 90, 0], ['SQM', 'SQM', 80, 0], ['CUSTOMS_YN', 'Customs', 80, 0], ['REMARKS', 'Ghi chú', 200, 0]];
let colCfg = {}; try { colCfg = JSON.parse(localStorage.getItem('cols') || 'null') || {}; } catch (_) {}
const saveCols = () => { try { localStorage.setItem('cols', JSON.stringify(colCfg)); } catch (_) {} };
const colOn = c => (colCfg.on && c[0] in colCfg.on) ? !!colCfg.on[c[0]] : !!c[3];
const colW = c => (colCfg.w && colCfg.w[c[0]]) || c[2];
const visCols = () => ALLCOLS.filter(colOn);
let suppressSort = false;
const FILTER_KEYS = ['PACKAGE_LIST_NO', 'PACKAGE_NO', 'DESCRIPTION', 'IS_CONFIRM_MATERIAL', 'RECEIPTED', 'ATTRIBUTE10', 'REMARK', 'VENDOR', 'LOCATION', 'START_RECEIPT_DATE', 'END_RECEIPT_DATE', 'MRR_RECEIVED', 'START_MRR_RECEIVED_DATE', 'END_MRR_RECEIVED_DATE', 'CUSTOMS_YN', 'MIR_CATEGORY', 'PACKAGE_STATUS'];
let project = null, rows = [], sel = new Set(), cur = -1, sortK = 'PACKAGE_NO', sortD = 1;

function status(t, err) { const e = $('#st'); e.textContent = t || ''; e.className = err ? 'err' : ''; }
async function api(p, f) {
  const r = await desm.post(p, f);
  if (r.error === 'login') { $('#loginbar').style.display = 'flex'; throw new Error('Chưa đăng nhập hoặc phiên đã hết hạn'); }
  if (r.json) $('#loginbar').style.display = 'none';
  if (!r.json) throw new Error('Phản hồi không hợp lệ (' + (r.status || r.error || '?') + ')');
  return r.json;
}
async function getProject() {
  if (project) return project;
  try { const j = await api('/getInitDefailProject.do', {}); const a = Array.isArray(j.results) ? j.results[0] : j.results; project = (a && a.SEGMENT1) || 'T25026'; }
  catch (e) { if (/đăng nhập/.test(e.message)) throw e; project = 'T25026'; }
  return project;
}
function audit(entry) { try { const k = 'writeLog', a = JSON.parse(localStorage.getItem(k) || '[]'); a.push({ t: new Date().toISOString(), ...entry }); localStorage.setItem(k, JSON.stringify(a.slice(-200))); } catch (_) {} }
const pick = i => rows[i];
const selList = () => [...sel].sort((a, b) => a - b).map(pick);
const payload = list => JSON.stringify(list.map(r => ({ PROJECT_NO: r.PROJECT_NO || project, TRK_ITEM_NAME: r.TRK_ITEM_NAME, PACKAGE_NO: r.PACKAGE_NO, CODE_TYPE: 'SUMMARY' })));

async function search() {
  status('Đang tải…');
  try {
    const f = { PROJECT_NO: await getProject(), MRR_VISUAL_CHECK: 'All' };
    FILTER_KEYS.forEach(k => f[k] = '');
    f.PACKAGE_NO = $('#f-no').value.trim(); f.PACKAGE_LIST_NO = $('#f-pl').value.trim(); f.DESCRIPTION = $('#f-ds').value.trim(); f.LOCATION = $('#f-lc').value.trim();
    const j = await api('/getIdsmOsSummaryList.do', f);
    rows = Array.isArray(j.results) ? j.results : []; sel.clear(); cur = -1; page = 0; status(''); render(); showDetail();
  } catch (e) { status(e.message, true); }
}
function order() {
  const idx = rows.map((_, i) => i);
  idx.sort((a, b) => String(rows[a][sortK] ?? '').localeCompare(String(rows[b][sortK] ?? ''), 'vi', { numeric: true }) * sortD);
  return idx;
}
const PAGE = 200; let page = 0;
function pageIdx() {
  const o = order(), pages = Math.max(1, Math.ceil(o.length / PAGE));
  page = Math.min(Math.max(0, page), pages - 1);
  $('#pager').innerHTML = pages > 1 ? `<button class="btn" id="pg-prev"${page ? '' : ' disabled'}>‹</button> Trang ${page + 1}/${pages} <button class="btn" id="pg-next"${page < pages - 1 ? '' : ' disabled'}>›</button>` : '';
  return o.slice(page * PAGE, (page + 1) * PAGE);
}
function layout() {
  const vc = visCols();
  $('#cg').innerHTML = '<col style="width:36px">' + vc.map(c => `<col style="width:${colW(c)}px">`).join('');
  const t = $('#tw table'); t.style.tableLayout = 'fixed'; t.style.width = '100%'; t.style.minWidth = (36 + vc.reduce((a, c) => a + colW(c), 0)) + 'px';
}
function render() {
  layout();
  $('#th').innerHTML = '<tr><th style="width:36px"><input type="checkbox" id="all" aria-label="Chọn tất cả"></th>' + visCols().map(([k, n]) => `<th data-k="${k}">${n}${sortK === k ? (sortD > 0 ? ' ↑' : ' ↓') : ''}<span class="rz" data-rz="${k}"></span></th>`).join('') + '</tr>';
  $('#tb').innerHTML = pageIdx().map(i => `<tr class="row${i === cur ? ' cur' : ''}" data-i="${i}"><td><input type="checkbox" data-c="${i}"${sel.has(i) ? ' checked' : ''} aria-label="Chọn dòng"></td>` + visCols().map(([k]) => `<td title="${esc(rows[i][k])}">${esc(rows[i][k])}</td>`).join('') + '</tr>').join('');
  $('#cnt').textContent = rows.length ? `${rows.length} kiện · đã chọn ${sel.size}` : 'Không có dữ liệu';
  $('#sbc').textContent = rows.length ? `${sel.size}/${rows.length} đã chọn` + (project ? ' · Dự án ' + project : '') : '';
  ['#b-loc', '#b-del', '#b-conf', '#b-canc', '#b-doc'].forEach(s => $(s).disabled = !sel.size); $('#b-csv').disabled = $('#b-xlsx').disabled = !rows.length;
}
function showDetail() {
  const r = rows[cur], d = $('#detail');
  if (!r) { d.innerHTML = '<div style="color:var(--tx2);font-size:13px">Chọn một kiện để xem chi tiết.</div>'; return; }
  const kv = [['Package No', r.PACKAGE_NO], ['PL No', r.PACKAGE_LIST_NO], ['Mô tả', r.DESCRIPTION], ['Loại', r.PACKAGE_TYPE], ['SL tổng/đã xuất', r.OUT_STATUS_QTY], ['Trạng thái', r.PACKAGE_STATUS], ['Location', r.STORAGE_LOCATION],
    ['Cập nhật vị trí', [r.LOC_UPDATED_BY, r.LOC_UPDATE_DATE].filter(Boolean).join(' · ')], ['Xác nhận', [r.CONFIRMED_BY, r.CONFIRM_DATE].filter(Boolean).join(' · ')],
    ['Dài (cm)', r.L_CM], ['Gross', r.GROSS], ['Volume', r.VOLUME], ['SQM', r.SQM], ['Customs', r.CUSTOMS_YN], ['Ghi chú', r.REMARKS]];
  d.innerHTML = `<div style="font-size:16px;font-weight:600;margin-bottom:10px">${esc(r.PACKAGE_NO)}</div><div class="kv">${kv.filter(x => x[1] !== undefined && x[1] !== '').map(([a, b]) => `<b>${a}</b><span>${esc(b)}</span>`).join('')}</div>` +
    `<div class="chips"><span class="chip">Short ${esc(r.REPORT_SHORT ?? 0)}</span><span class="chip">Over ${esc(r.REPORT_OVER ?? 0)}</span><span class="chip">DMG ${esc(r.REPORT_DMG ?? 0)}</span><span class="chip">Missing ${esc(r.REPORT_MISSING ?? 0)}</span></div>` +
    '<div style="font-weight:600;font-size:14px;margin:12px 0 6px">Hạng mục chi tiết</div><div id="items" style="font-size:13px;color:var(--tx2)">Đang tải…</div>';
  loadItems(r);
}
// ---- Hạng mục chi tiết (getIdsmOsDetailList) ----
let items = [], itemSel = new Set(), itemTok = 0;
const remainOf = i => i.REMAIN_QTY !== undefined && i.REMAIN_QTY !== '' ? Number(i.REMAIN_QTY) : (Number(i.IN_QTY) || 0) - (Number(i.OUT_QTY) || 0);
async function loadItems(r) {
  const tok = ++itemTok; items = []; itemSel = new Set();
  try {
    const pj = await getProject();
    const j = await api('/getIdsmOsDetailList.do', { PAGE_NUM: '1', PAGE_CNT: '5000', PROJECT_NO: pj, PACKAGE_LIST_NO: '', PACKAGE_NO: r.PACKAGE_NO, DESCRIPTION: '', DRAWING_NO: '', TAG_NO: '', QTY_TYPE: 'rsi', QTY: '', KEY1: '', VALUE1: '', LOCATION: '', SEQUENCE: '', VENDOR: '', ATTRIBUTE10: '', TYPE: '', CATEGORY: '', SUB_CATEGORY: '', COMMENTS: '' });
    if (tok !== itemTok) return;
    const x = j.results; const l = Array.isArray(x) ? x : (x && x.list) || [];
    items = l.filter(i => (i.PACKAGE_NO ?? r.PACKAGE_NO) === r.PACKAGE_NO); renderItems();
  } catch (e) { if (tok === itemTok && $('#items')) $('#items').textContent = e.message; }
}
function renderItems() {
  const box = $('#items'); if (!box) return;
  if (!items.length) { box.textContent = 'Kiện này chưa có hạng mục.'; return; }
  box.innerHTML = `<div style="display:flex;gap:6px;margin-bottom:8px"><button class="btn" id="i-all">Chọn tất cả</button><button class="btn pri" id="i-loc"${itemSel.size ? '' : ' disabled'}>Location Update (${itemSel.size})</button><button class="btn dan" id="i-del"${itemSel.size ? '' : ' disabled'}>Xoá VT</button></div>` +
    items.map((it, n) => `<label style="display:flex;gap:8px;align-items:flex-start;border:1px solid ${itemSel.has(n) ? 'var(--pri)' : 'var(--bd)'};background:${itemSel.has(n) ? 'var(--sel)' : 'var(--card)'};border-radius:8px;padding:8px;margin-bottom:6px;color:var(--tx)"><input type="checkbox" data-it="${n}"${itemSel.has(n) ? ' checked' : ''}><span><b>${esc(it.MATERIAL_CODE)}</b> ${esc(it.DESCRIPTION)}<br><span style="color:var(--tx2)">${esc(it.UNIT)} · còn ${esc(remainOf(it))} · ${esc(it.LOCATION || 'chưa có vị trí')}</span>${canEdit(it) ? `<br><button type="button" class="btn" data-ed="${n}" style="height:26px;padding:0 8px;margin-top:4px">Sửa Short/Over/DMG/Missing</button>` : ''}${it.TRK_ITEM_NAME ? ` <button type="button" class="btn" data-lg="${n}" style="height:26px;padding:0 8px;margin-top:4px">Edit Log</button>` : ''}</span></label>`).join('');
}
const itemParams = () => [...itemSel].sort((a, b) => a - b).map(n => ({ PROJECT_NO: items[n].PROJECT_NO || project, TRK_ITEM_NAME: items[n].TRK_ITEM_NAME, MATERIAL_CODE: items[n].MATERIAL_CODE, CODE_TYPE: 'DETAIL' }));
function itemBlock() {
  const ls = [...itemSel].map(n => items[n]);
  if (!ls.length) return 'Hãy chọn ít nhất một hạng mục.';
  if (ls.some(i => !i.TRK_ITEM_NAME)) return 'Thiếu TRK_ITEM_NAME của hạng mục nên chưa thao tác được.';
  if (ls.some(i => remainOf(i) <= 0)) return 'Hạng mục có số lượng còn lại 0 nên không cập nhật vị trí được.';
  return null;
}
$('#detail').addEventListener('click', e => {
  const lg = e.target.closest('[data-lg]');
  if (lg) { e.preventDefault(); openLog(+lg.dataset.lg); return; }
  const ed = e.target.closest('[data-ed]');
  if (ed) { e.preventDefault(); openEdit(+ed.dataset.ed); return; }
  const c = e.target.closest('[data-it]');
  if (c) { const n = +c.dataset.it; c.checked ? itemSel.add(n) : itemSel.delete(n); renderItems(); return; }
  if (e.target.id === 'i-all') { itemSel = itemSel.size === items.length ? new Set() : new Set(items.map((_, n) => n)); renderItems(); return; }
  if (e.target.id === 'i-loc') { const b = itemBlock(); if (b) return status(b, true); openLoc({ payload: JSON.stringify(itemParams()), count: itemSel.size, names: itemParams().map(p => p.MATERIAL_CODE), after: () => loadItems(rows[cur]) }); return; }
  if (e.target.id === 'i-del') { const b = itemBlock(); if (b) return status(b, true); doDelete({ payload: JSON.stringify(itemParams()), count: itemSel.size, names: itemParams().map(p => p.MATERIAL_CODE), after: () => loadItems(rows[cur]) }); }
});
$('#tb').addEventListener('click', e => {
  const c = e.target.closest('[data-c]');
  if (c) { const i = +c.dataset.c; c.checked ? sel.add(i) : sel.delete(i); render(); return; }
  const tr = e.target.closest('tr.row'); if (tr) { cur = +tr.dataset.i; render(); showDetail(); }
});
$('#th').addEventListener('click', e => {
  if (e.target.id === 'all') { sel = e.target.checked ? new Set(rows.map((_, i) => i)) : new Set(); render(); return; }
  const th = e.target.closest('th[data-k]'); if (!th || suppressSort) return;
  sortD = sortK === th.dataset.k ? -sortD : 1; sortK = th.dataset.k; page = 0; render();
});
$('#pager').addEventListener('click', e => { if (e.target.id === 'pg-prev') page--; else if (e.target.id === 'pg-next') page++; else return; render(); $('#tw').scrollTop = 0; });
$('#b-login').onclick = () => { document.querySelector('#side button[data-v="web"]').click(); document.dispatchEvent(new CustomEvent('goto-login')); };
document.querySelector('#side button[data-v="pkg"]').addEventListener('click', () => { if ($('#loginbar').style.display !== 'none') search(); });
// ---- Kéo đổi độ rộng cột, chọn/ẩn cột ----
document.addEventListener('mousedown', e => {
  const h = e.target.closest('.rz'); if (!h) return; e.preventDefault(); e.stopPropagation();
  const k = h.dataset.rz, c = ALLCOLS.find(x => x[0] === k), x0 = e.clientX, w0 = colW(c);
  const mv = ev => { colCfg.w = colCfg.w || {}; colCfg.w[k] = Math.max(50, Math.round(w0 + ev.clientX - x0)); layout(); };
  const up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); saveCols(); suppressSort = true; setTimeout(() => { suppressSort = false; }, 0); };
  addEventListener('mousemove', mv); addEventListener('mouseup', up);
});
function colMenu(x, y) {
  showMenu(x, y, ALLCOLS.map(c => ({ label: (colOn(c) ? '✓  ' : '      ') + c[1], fn: () => {
    if (colOn(c) && visCols().length <= 1) { colMenu(x, y); return; }
    colCfg.on = colCfg.on || {}; colCfg.on[c[0]] = !colOn(c); saveCols(); render(); colMenu(x, y);
  } })).concat([{ sep: true }, { label: 'Đặt lại cột mặc định', fn: () => { colCfg = {}; saveCols(); render(); } }]));
}
$('#b-cols').onclick = e => { const r = e.currentTarget.getBoundingClientRect(); colMenu(r.left, r.bottom + 4); };
// ---- Xuất Excel (.xlsx) theo cột đang hiển thị, đúng thứ tự đang sắp xếp ----
$('#b-xlsx').onclick = async () => {
  const vc = visCols(), blob = window.makeXlsx('Package', vc.map(c => c[1]), vc.map(colW), order().map(i => vc.map(([k]) => rows[i][k] ?? '')));
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'package-' + new Date().toISOString().slice(0, 10) + '.xlsx'; a.click();
  status('Đã xuất ' + rows.length + ' dòng ra Excel');
};
// ---- Bộ lọc đã lưu ----
const getPre = () => { try { return JSON.parse(localStorage.getItem('presets') || '[]'); } catch (_) { return []; } };
const setPre = a => { try { localStorage.setItem('presets', JSON.stringify(a)); } catch (_) {} };
const curFilter = () => ({ no: $('#f-no').value.trim(), pl: $('#f-pl').value.trim(), ds: $('#f-ds').value.trim(), lc: $('#f-lc').value.trim() });
const applyFilter = f => { $('#f-no').value = f.no || ''; $('#f-pl').value = f.pl || ''; $('#f-ds').value = f.ds || ''; $('#f-lc').value = f.lc || ''; search(); };
$('#b-pre').onclick = e => {
  const r = e.currentTarget.getBoundingClientRect(), a = getPre();
  showMenu(r.left, r.bottom + 4, [].concat(
    a.length ? a.map(p => ({ label: p.name, fn: () => applyFilter(p.f) })) : [{ label: '(chưa có bộ lọc đã lưu)', dis: true }],
    [{ sep: true }, { label: 'Lưu bộ lọc hiện tại…', fn: () => { $('#pname').value = ''; $('#pmodal').style.display = 'flex'; $('#pname').focus(); } }],
    a.length ? [{ sep: true }, { head: 'Xoá bộ lọc' }].concat(a.map(p => ({ label: '✕ ' + p.name, fn: () => { if (confirm('Xoá bộ lọc "' + p.name + '"?')) setPre(getPre().filter(x => x.name !== p.name)); } }))) : []));
};
$('#p-cancel').onclick = () => { $('#pmodal').style.display = 'none'; };
$('#p-ok').onclick = () => {
  const name = $('#pname').value.trim(); if (!name) return;
  setPre(getPre().filter(x => x.name !== name).concat([{ name, f: curFilter() }])); $('#pmodal').style.display = 'none'; status('Đã lưu bộ lọc "' + name + '"');
};
$('#pname').addEventListener('keydown', e => { if (e.key === 'Enter') $('#p-ok').click(); });
$('#b-search').onclick = search;
$('#b-reset').onclick = () => { ['#f-no', '#f-pl', '#f-ds', '#f-lc'].forEach(s => $(s).value = ''); search(); };
document.querySelectorAll('#filters input').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') search(); }));
$('#b-csv').onclick = () => {
  const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = '\ufeff' + [visCols().map(c => q(c[1])).join(',')].concat(order().map(i => visCols().map(([k]) => q(rows[i][k])).join(','))).join('\r\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = 'package.csv'; a.click();
};

// ---- Location Update (dùng chung cho kiện và hạng mục) ----
let mapId = null, cellId = null, cellName = '', locCtx = null;
const modal = $('#modal');
let cellData = [], mapList = [];
const imgCache = new Map();
const nums = t => String(t).split(',').map(x => parseFloat(x)).filter(isFinite);
function shapeOf(c) {
  const T = `data-id="${esc(c.id)}"><title>${esc(c.name)}</title>`;
  if (c.type === 'RECT') { const a = nums(c.pos); return a.length >= 4 ? `<rect class="cell" x="${a[0]}" y="${a[1]}" width="${a[2]}" height="${a[3]}" ${T}</rect>` : ''; }
  if (c.type === 'LINE') { const pts = String(c.pos).split(';').map(nums).filter(a => a.length >= 2); return pts.length >= 2 ? `<polygon class="cell" points="${pts.map(a => a[0] + ',' + a[1]).join(' ')}" ${T}</polygon>` : ''; }
  return '';
}
function drawMap(src, err) {
  const shapes = cellData.map(shapeOf).join('');
  if (!src && !shapes) { $('#mapbox').innerHTML = `<div style="padding:12px;color:var(--tx2);font-size:13px">${esc(err || 'Bản đồ không có ảnh/ô vị trí')}</div>`; return; }
  $('#mapbox').innerHTML = `<svg viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Bản đồ vị trí">${src ? `<image href="${esc(src)}" x="0" y="0" width="1200" height="700" preserveAspectRatio="none"/>` : '<rect width="1200" height="700" style="fill:var(--mut)"/>'}${shapes}</svg>` + (err ? `<div style="padding:6px 10px;font-size:12px;color:var(--err)">Không tải được ảnh nền: ${esc(err)} (vẫn chọn được ô bằng danh sách bên dưới)</div>` : '');
  if (cellId) pickCell(cellId, true);
}
function pickCell(id, quiet) {
  const c = cellData.find(x => x.id === id); if (!c) return;
  cellId = c.id; cellName = c.name;
  document.querySelectorAll('#mapbox .cell').forEach(x => x.classList.toggle('on', x.dataset.id === id));
  document.querySelectorAll('#cells button').forEach(x => x.classList.toggle('on', x.dataset.id === id));
  $('#msel').textContent = 'Vị trí: ' + cellName; $('#m-ok').disabled = false;
  if (!quiet) { const b = document.querySelector('#cells button.on'); if (b) b.scrollIntoView({ block: 'nearest' }); }
}
async function loadCells() {
  const my = mapId = $('#maps').value; cellId = null; cellName = ''; $('#m-ok').disabled = true; $('#msel').textContent = '';
  try { localStorage.setItem('lastMap', my); } catch (_) {}
  $('#mapbox').innerHTML = '<div style="padding:14px;color:var(--tx2);font-size:13px">Đang tải bản đồ…</div>'; $('#cells').textContent = 'Đang tải…';
  try {
    const j = await api('/getDesmMapInfoList.do', { PROJECT_NO: project, MAP_MST_ID: my });
    if (my !== mapId) return;
    const res = j.results || {}, mst = (res.mstInfo || [])[0] || {};
    cellData = (res.dtlInfo || []).map(c => ({ id: String(c.MAP_DTL_ID ?? ''), name: c.MAP_NAME || String(c.MAP_DTL_ID ?? ''), type: c.MAP_TYPE || '', pos: c.MAP_POSITION || '' })).filter(c => c.id)
      .sort((a, b) => a.name.localeCompare(b.name, 'vi', { numeric: true }));
    $('#cells').innerHTML = cellData.map(c => `<button data-id="${esc(c.id)}" data-n="${esc(c.name)}">${esc(c.name)}</button>`).join('') || 'Bản đồ này chưa có ô vị trí';
    const path = mst.MAP_PATH || ((mapList.find(m => String(m.MAP_MST_ID) === my) || {}).MAP_PATH) || '';
    let src = imgCache.get(path) || '', err = '';
    drawMap(src, '');                       // hiện ô trước, ảnh nền tải xong sẽ vẽ lại
    if (path && !src) { const r = await window.desm.img(path); if (r.ok) { src = r.data; imgCache.set(path, src); } else err = r.error || 'lỗi'; }
    else if (!path) err = 'Bản đồ chưa có đường dẫn ảnh';
    if (my === mapId) drawMap(src, err);
  } catch (e) { $('#mapbox').textContent = e.message; $('#cells').textContent = ''; }
}
async function openLoc(ctx) {
  locCtx = ctx;
  try {
    await getProject(); const j = await api('/getDesmMapCreationList.do', { PROJECT_NO: project });
    const ml = Array.isArray(j.results) ? j.results : [];
    if (!ml.length) { status('Không có bản đồ vị trí', true); return; }
    $('#maps').innerHTML = ml.map(m => `<option value="${esc(m.MAP_MST_ID)}">${esc(m.MAP_NAME)}</option>`).join('');
    mapList = ml; let last = ''; try { last = localStorage.getItem('lastMap') || ''; } catch (_) {}
    if (ml.some(m => String(m.MAP_MST_ID) === last)) $('#maps').value = last;
    $('#mtitle').textContent = `Location Update (${ctx.count}) — bấm vào ô trên bản đồ để chọn vị trí`; modal.classList.add('on'); loadCells();
  } catch (e) { status(e.message, true); }
}
$('#b-loc').onclick = () => openLoc({ payload: payload(selList()), count: sel.size, names: selList().map(r => r.PACKAGE_NO), after: search });
$('#maps').onchange = loadCells;
$('#cells').addEventListener('click', e => { const b = e.target.closest('button'); if (b) pickCell(b.dataset.id); });
$('#mapbox').addEventListener('click', e => { const c = e.target.closest('.cell'); if (c) pickCell(c.dataset.id, true); });
$('#m-cancel').onclick = () => modal.classList.remove('on');
$('#m-ok').onclick = async () => {
  const ctx = locCtx, body = { list: ctx.payload, MAP_MST_ID: mapId, MAP_DTL_ID: cellId };
  try {
    const c = await api('/saveDesmLocationCheck.do', body);
    const diff = c.LOCATION_DIFF ?? (c.results && (c.results.LOCATION_DIFF ?? (c.results[0] && c.results[0].LOCATION_DIFF)));
    if (diff && !confirm('Có mục đang ở vị trí khác (' + (typeof diff === 'string' ? diff : 'xem danh sách') + ').\nVẫn đổi sang ' + cellName + '?')) return;
    if (!confirm(`Cập nhật vị trí ${cellName} cho ${ctx.count} mục?`)) return;
    const j = await api('/saveDesmLocation.do', body);
    audit({ op: 'location-update', cell: cellName, items: ctx.names, res: j.success || j.error });
    if (!j.error) { modal.classList.remove('on'); status('Đã cập nhật vị trí'); ctx.after(); }
    else status(j.error === 'qtyCheckErr' ? 'Số lượng 0 không đổi được: ' + (j.PACKAGE_NO || '') : 'Lỗi: ' + (j.error || 'không rõ'), true);
  } catch (e) { status(e.message, true); }
};
async function doDelete(ctx) {
  if (!confirm(`XOÁ vị trí của ${ctx.count} mục?`)) return;
  try {
    const j = await api('/deleteDesmLocation.do', { deleteList: ctx.payload });
    const er = j.error || (j.result && j.result.error);
    audit({ op: 'location-delete', items: ctx.names, res: er || 'OK' });
    if (er) status('Lỗi: ' + er, true); else { status('Đã xoá vị trí'); ctx.after(); }
  } catch (e) { status(e.message, true); }
}
async function matWrite(path, label) {
  const list = selList();
  if (!list.length) return;
  if (!confirm(`${label} cho ${list.length} kiện?`)) return;
  try {
    const j = await api(path, { list: JSON.stringify(list.map(r => ({ PROJECT_NO: r.PROJECT_NO || project, TRK_ITEM_NAME: r.TRK_ITEM_NAME, PACKAGE_NO: r.PACKAGE_NO }))) });
    audit({ op: label, pkgs: list.map(r => r.PACKAGE_NO), res: j.error || 'OK' });
    if (j.error === 'RSI') status('Kiện đã có RSI nên không hủy xác nhận được: ' + (j.PACKAGE_NO || ''), true);
    else if (j.error) status('Lỗi: ' + j.error, true);
    else { status('Đã ' + label.toLowerCase()); search(); }
  } catch (e) { status(e.message, true); }
}
$('#b-conf').onclick = () => matWrite('/saveIdsmOsSummaryListConfirmMaterial.do', 'Material Confirm');
$('#b-canc').onclick = () => matWrite('/saveIdsmOsSummaryListCancelMaterial.do', 'Hủy xác nhận');
// ---- Sửa hạng mục (saveIdsmOsDetailList) — theo btnSaveClick của plDetail.js ----
const FLAGS = [['REPORT_SHORT', 'SHORT'], ['REPORT_OVER', 'OVER'], ['REPORT_DMG', 'DMG'], ['REPORT_MISSING', 'MISSING']];
const canEdit = it => !!it.TRK_ITEM_NAME && String(it.IS_CONFIRM_MATERIAL || '').toUpperCase() === 'Y';
const num = v => { const n = parseFloat(v); return isFinite(n) ? n : 0; };
let editIdx = -1;
function openEdit(n) {
  editIdx = n; const it = items[n];
  $('#etitle').textContent = 'Sửa ' + it.MATERIAL_CODE; $('#eerr').textContent = '';
  $('#eflags').innerHTML = FLAGS.map(([k, name]) => { const q = num(it[k + '_QTY']), on = num(it[k]) > 0 || q > 0;
    return `<label><input type="checkbox" data-fk="${k}"${on ? ' checked' : ''}> ${name}</label><input type="number" min="0" step="any" data-fq="${k}" value="${q > 0 ? q : ''}" placeholder="Số lượng" style="height:32px;border:1px solid var(--bd2);border-radius:6px;padding:0 8px">`; }).join('');
  $('#erem').value = it.REMARKS || ''; $('#emodal').style.display = 'flex';
}
$('#e-cancel').onclick = () => { $('#emodal').style.display = 'none'; };
$('#e-ok').onclick = async () => {
  const it = items[editIdx], vals = {};
  for (const [k, name] of FLAGS) {
    const on = document.querySelector(`[data-fk="${k}"]`).checked, q = on ? num(document.querySelector(`[data-fq="${k}"]`).value) : 0;
    if (on && q <= 0) { $('#eerr').textContent = 'Nhập số lượng > 0 cho ' + name; return; }
    const orig = it[k + '_QTY'];
    vals[k] = on ? q : (orig === '' || orig == null ? '' : 0);
  }
  const inQ = num(it.IN_QTY);
  if (inQ < num(it.RSI_QTY) - num(it.MRF_QTY)) { $('#eerr').textContent = "In Q'ty nhỏ hơn (RSI Q'ty − MRF Q'ty), không thể lưu."; return; }
  const row = { PROJECT_NO: it.PROJECT_NO || project, TRK_ITEM_NAME: it.TRK_ITEM_NAME, PACKAGE_NO: it.PACKAGE_NO, MATERIAL_CODE: it.MATERIAL_CODE, ITEM_SIZE: it.ITEM_SIZE ?? '', DESCRIPTION: it.DESCRIPTION ?? '', DRAWING_NO: it.DRAWING_NO ?? '', LOCATION: it.LOCATION ?? '', TAG_NO: it.TAG_NO ?? '', UNIT: it.UNIT ?? '', MATERIAL: it.MATERIAL ?? '', REMARKS: $('#erem').value, IN_QTY: (it.IN_QTY === '' || it.IN_QTY == null) ? '' : inQ };
  FLAGS.forEach(([k]) => { row[k] = num(vals[k]) > 0 ? '1' : '0'; row[k + '_QTY'] = vals[k] ?? ''; });
  if (!confirm('Lưu thay đổi cho hạng mục ' + it.MATERIAL_CODE + '?')) return;
  const before = { MATERIAL_CODE: it.MATERIAL_CODE, REMARKS: it.REMARKS }; FLAGS.forEach(([k]) => { before[k] = it[k]; before[k + '_QTY'] = it[k + '_QTY']; });
  try {
    const j = await api('/saveIdsmOsDetailList.do', { list: JSON.stringify([row]) });
    audit({ op: 'item-save', item: it.MATERIAL_CODE, before, sent: row, res: j.error || 'OK' });
    if (j.error) { $('#eerr').textContent = 'Lỗi: ' + j.error; return; }
    $('#emodal').style.display = 'none'; status('Đã lưu hạng mục'); loadItems(rows[cur]);
  } catch (e) { $('#eerr').textContent = e.message; }
};
// ---- Edit Log hạng mục (getDesmPlDetailEditLogList, chỉ đọc) ----
const LOGF = [['LOCATION', 'Location'], ['IN_QTY', "In Q'ty"], ['REMARKS', 'Remarks'], ['UNIT', 'Unit'], ['DESCRIPTION', 'Mô tả'], ['DRAWING_NO', 'Drawing'], ['TAG_NO', 'Tag'], ['MATERIAL', 'Material'], ['REPORT_SHORT_QTY', 'Short'], ['REPORT_OVER_QTY', 'Over'], ['REPORT_DMG_QTY', 'DMG'], ['REPORT_MISSING_QTY', 'Missing']];
async function openLog(n) {
  const it = items[n];
  $('#ltitle').textContent = 'Edit Log · ' + it.MATERIAL_CODE; $('#lbody').textContent = 'Đang tải…'; $('#lmodal').style.display = 'flex';
  try {
    const j = await api('/getDesmPlDetailEditLogList.do', { PROJECT_NO: it.PROJECT_NO || project, TRK_ITEM_NAME: it.TRK_ITEM_NAME, MATERIAL_CODE: it.MATERIAL_CODE });
    const x = j.results; const l = (Array.isArray(x) ? x.slice() : (x && x.list) || []);
    l.sort((a, b) => String(b.CREATION_DATE_TXT || '').localeCompare(String(a.CREATION_DATE_TXT || '')));
    $('#lbody').innerHTML = l.length ? l.map((r, i) => {
      const o = l[i + 1];
      const ch = o ? (LOGF.filter(([k]) => String(r[k] ?? '') !== String(o[k] ?? '')).map(([k, nm]) => `<div>${nm}: <s>${esc(o[k])}</s> → <b>${esc(r[k])}</b></div>`).join('') || '<div style="color:var(--tx2)">Không đổi trường nào</div>')
        : '<div style="color:var(--tx2)">Bản ghi đầu tiên</div>' + LOGF.filter(([k]) => r[k] !== undefined && r[k] !== '' && r[k] !== null).map(([k, nm]) => `<div>${nm}: ${esc(r[k])}</div>`).join('');
      return `<div style="border:1px solid var(--bd);border-radius:8px;padding:10px;margin-bottom:8px"><div style="font-weight:600;margin-bottom:4px">${esc(r.CREATION_DATE_TXT)} · ${esc(r.CREATED_BY)}</div>${ch}</div>`;
    }).join('') : 'Chưa có lịch sử chỉnh sửa.';
  } catch (e) { $('#lbody').textContent = e.message; }
}
$('#l-close').onclick = () => { $('#lmodal').style.display = 'none'; };
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { $('#pmodal').style.display = 'none'; $('#lmodal').style.display = 'none'; $('#emodal').style.display = 'none'; modal.classList.remove('on'); }
});
// ---- Nhật ký thao tác ghi (lưu trên máy này) ----
$('#b-log').onclick = () => {
  let a = []; try { a = JSON.parse(localStorage.getItem('writeLog') || '[]'); } catch (_) {}
  $('#ltitle').textContent = 'Nhật ký thao tác ghi (' + a.length + ')'; $('#lmodal').style.display = 'flex';
  const names = x => (x.pkgs || x.items || (x.item ? [x.item] : [])).join(', ');
  $('#lbody').innerHTML = (a.length ? '<button class="btn" id="log-exp" style="margin-bottom:8px">Xuất JSON</button>' : '') + (a.slice().reverse().map(x => `<div style="border:1px solid var(--bd);border-radius:8px;padding:8px 10px;margin-bottom:6px"><b>${esc(x.op)}</b> · ${esc(new Date(x.t).toLocaleString('vi-VN'))}<br>${esc(names(x))}${x.cell ? ' → ' + esc(x.cell) : ''}<br><span style="color:${x.res === 'OK' ? 'var(--ok)' : 'var(--err)'}">Kết quả: ${esc(x.res)}</span></div>`).join('') || 'Chưa có thao tác ghi nào.');
  const ex = $('#log-exp'); if (ex) ex.onclick = () => { const l = document.createElement('a'); l.href = URL.createObjectURL(new Blob([JSON.stringify(a, null, 2)], { type: 'application/json' })); l.download = 'desm-write-log.json'; l.click(); };
};
// ---- MIR / RFI (check -> save, theo plSummary.js; popup TẠO phiếu chưa hỗ trợ) ----
const pkgBody = list => ({ list: JSON.stringify(list.map(r => ({ PROJECT_NO: r.PROJECT_NO || project, TRK_ITEM_NAME: r.TRK_ITEM_NAME, PACKAGE_NO: r.PACKAGE_NO }))) });
const DOC_VI = { create: 'tạo phiếu', accept: 'chấp nhận', cancel: 'hủy' };
async function docFlow(K, act) {
  const list = selList(); if (!list.length) { status('Chọn ít nhất 1 kiện', true); return; }
  const body = pkgBody(list), names = list.map(r => r.PACKAGE_NO);
  try {
    const c = await api('/getIdsmOsSummaryList' + K + { create: 'Check', accept: 'AcceptCheck', cancel: 'CancelCheck' }[act] + '.do', body);
    if (c.error != null) { status('Lỗi: ' + c.error, true); return; }
    const bad = (c.results && c.results.checkList) || [];
    if (bad.length) { alert(`Không thể ${DOC_VI[act]} ${K.toUpperCase()} với các kiện:\n` + bad.map(x => x.PACKAGE_NO).join('\n')); return; }
    if (act === 'create') { audit({ op: K + ' check', pkgs: names, res: 'OK' }); alert(`Các kiện đủ điều kiện tạo ${K.toUpperCase()}.\nPopup tạo phiếu chưa hỗ trợ trong bản PC: hãy tạo ở tab "Trình duyệt DESM".`); return; }
    if (!confirm(`${DOC_VI[act][0].toUpperCase() + DOC_VI[act].slice(1)} ${K.toUpperCase()} cho ${list.length} kiện?`)) return;
    const j = await api('/saveIdsmOsSummaryList' + K + (act === 'accept' ? 'Accept' : 'Cancel') + '.do', body);
    audit({ op: K + ' ' + act, pkgs: names, res: j.error || 'OK' });
    if (j.error != null) status('Lỗi: ' + j.error, true); else { status('Đã ' + DOC_VI[act] + ' ' + K.toUpperCase()); search(); }
  } catch (e) { status(e.message, true); }
}
const docItems = () => ['Rfi', 'Mir'].flatMap(K => [{ head: K.toUpperCase() }, { label: 'Kiểm tra điều kiện tạo phiếu', fn: () => docFlow(K, 'create') }, { label: 'Chấp nhận ' + K.toUpperCase(), fn: () => docFlow(K, 'accept') }, { label: 'Hủy ' + K.toUpperCase(), fn: () => docFlow(K, 'cancel') }]);
// ---- Menu chuột phải / menu thả xuống ----
const ctx = $('#ctx');
function showMenu(x, y, items) {
  ctx.innerHTML = items.map((it, i) => it.sep ? '<hr>' : it.head ? `<div class="hd">${esc(it.head)}</div>` : `<div data-m="${i}"${it.dis ? ' class="dis"' : ''}>${esc(it.label)}</div>`).join('');
  ctx.style.display = 'block'; ctx.style.left = Math.min(x, innerWidth - 230) + 'px'; ctx.style.top = Math.min(y, innerHeight - ctx.offsetHeight - 8) + 'px';
  ctx.onclick = e => { const d = e.target.closest('[data-m]'); if (!d || d.classList.contains('dis')) return; ctx.style.display = 'none'; items[+d.dataset.m].fn(); };
}
document.addEventListener('mousedown', e => { if (!e.target.closest('#ctx')) ctx.style.display = 'none'; });
document.addEventListener('keydown', e => { if (e.key === 'Escape') ctx.style.display = 'none'; });
$('#b-doc').onclick = e => { const r = e.currentTarget.getBoundingClientRect(); showMenu(r.left, r.bottom + 4, docItems()); };
$('#tb').addEventListener('contextmenu', e => {
  const tr = e.target.closest('tr.row'); if (!tr) return; e.preventDefault();
  const i = +tr.dataset.i; if (!sel.has(i)) { sel = new Set([i]); } cur = i; render(); showDetail();
  showMenu(e.clientX, e.clientY, [
    { label: `Location Update (${sel.size})`, fn: () => $('#b-loc').click() }, { label: 'Material Confirm', fn: () => $('#b-conf').click() }, { label: 'Hủy xác nhận', fn: () => $('#b-canc').click() },
    { sep: true }, ...docItems(), { sep: true },
    { label: 'Sao chép Package No', fn: () => navigator.clipboard.writeText(rows[i].PACKAGE_NO || '').then(() => status('Đã sao chép ' + rows[i].PACKAGE_NO)) }]);
});
// ---- Bàn phím trong bảng + lệnh từ menu gốc ----
document.addEventListener('keydown', e => {
  if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || !$('#v-pkg').classList.contains('on') || document.querySelector('#modal.on')) return;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    const ord = order(); if (!ord.length) return; e.preventDefault();
    let p = ord.indexOf(cur); p = e.key === 'ArrowDown' ? Math.min(ord.length - 1, p + 1) : Math.max(0, p < 0 ? 0 : p - 1);
    cur = ord[p]; page = Math.floor(p / PAGE); render(); showDetail(); const r = document.querySelector('tr.cur'); if (r) r.scrollIntoView({ block: 'nearest' });
  } else if (e.key === ' ' && cur >= 0) { e.preventDefault(); sel.has(cur) ? sel.delete(cur) : sel.add(cur); render(); }
  else if (e.ctrlKey && e.key.toLowerCase() === 'a' && rows.length) { e.preventDefault(); sel = new Set(rows.map((_, i) => i)); render(); }
});
document.addEventListener('menu', e => {
  const a = e.detail;
  if (a === 'refresh' || a === 'reload') search();
  else if (a === 'search-focus') { $('#f-no').focus(); $('#f-no').select(); }
  else if (a === 'export-csv') $('#b-csv').click();
  else if (a === 'export-xlsx') $('#b-xlsx').click();
  else if (a === 'write-log') $('#b-log').click();
});
$('#b-del').onclick = () => doDelete({ payload: payload(selList()), count: sel.size, names: selList().map(r => r.PACKAGE_NO), after: search });
search();

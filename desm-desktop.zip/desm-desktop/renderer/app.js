const wv = document.getElementById('wv'), url = document.getElementById('url'), zl = document.getElementById('z');
let zoom = Number(localStorage.getItem('zoom') || 1);
const norm = s => { s = s.trim(); if (!s) return ''; return /^https?:\/\//i.test(s) ? s : 'https://' + s; };
const setZoom = z => { zoom = Math.min(2, Math.max(0.5, Math.round(z * 10) / 10)); wv.setZoomFactor(zoom); zl.textContent = Math.round(zoom * 100) + '%'; localStorage.setItem('zoom', zoom); };
wv.addEventListener('dom-ready', async () => { setZoom(zoom); try { await wv.executeJavaScript(await window.desm.getDodo()); } catch (_) {} });
const viBtn = document.getElementById('vi');
const showVi = on => { viBtn.classList.toggle('on', on); viBtn.textContent = on ? 'VI ✓' : 'VI'; };
(async () => {   // thứ tự: đặt Việt hoá + preload TRƯỚC khi nạp trang
  let vi = localStorage.getItem('vi') !== '0';
  await window.desm.setVi(vi); showVi(vi);
  viBtn.onclick = async () => { vi = !vi; localStorage.setItem('vi', vi ? '1' : '0'); await window.desm.setVi(vi); showVi(vi); wv.reload(); };
  wv.setAttribute('preload', await window.desm.webPreloadUrl());
  wv.setAttribute('nodeintegrationinsubframes', '');
  wv.src = 'https://desm.doosanenerbility.com';
})();
wv.addEventListener('did-navigate', e => { url.value = e.url; });
wv.addEventListener('did-navigate-in-page', e => { if (e.isMainFrame) url.value = e.url; });
url.addEventListener('keydown', e => { if (e.key === 'Enter') { const u = norm(url.value); if (u) wv.loadURL(u); } });
document.getElementById('back').onclick = () => wv.canGoBack() && wv.goBack();
document.getElementById('fwd').onclick = () => wv.canGoForward() && wv.goForward();
document.getElementById('reload').onclick = () => wv.reload();
document.getElementById('zin').onclick = () => setZoom(zoom + 0.1);
document.getElementById('zout').onclick = () => setZoom(zoom - 0.1);
document.getElementById('zreset').onclick = () => setZoom(1);
document.addEventListener('keydown', e => { if (e.altKey && e.key === 'd') { document.getElementById('v-web').classList.contains('on') && (url.focus(), url.select()); } });

document.querySelectorAll('#side button[data-v]').forEach(b => b.addEventListener('click', () => {
  document.querySelectorAll('#side button[data-v]').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + b.dataset.v));
}));

const themeBtn = document.getElementById('theme');
const applyTheme = d => { document.documentElement.classList.toggle('dark', d); document.getElementById('theme-t').textContent = d ? 'Chế độ sáng' : 'Chế độ tối'; };
{ const sv = localStorage.getItem('dark'); applyTheme(sv === null ? window.matchMedia('(prefers-color-scheme: dark)').matches : sv === '1'); }
themeBtn.addEventListener('click', () => { const d = !document.documentElement.classList.contains('dark'); localStorage.setItem('dark', d ? '1' : '0'); applyTheme(d); });

// ---- Menu gốc của cửa sổ (Tệp / Xem / Công cụ) ----
let pz = Number(localStorage.getItem('pkgZoom') || 1);
const setPz = z => { pz = Math.min(1.6, Math.max(0.7, Math.round(z * 10) / 10)); document.getElementById('v-pkg').style.zoom = pz; localStorage.setItem('pkgZoom', pz); };
setPz(pz);
const activeView = () => document.querySelector('.view.on').id;
window.desm.onMenu(a => {
  const web = activeView() === 'v-web';
  if (a === 'view-pkg' || a === 'view-web') document.querySelector(`#side button[data-v="${a.slice(5)}"]`).click();
  else if (a === 'zoom-in' || a === 'zoom-out' || a === 'zoom-reset') { const cur = web ? zoom : pz; const nz = a === 'zoom-reset' ? 1 : cur + (a === 'zoom-in' ? 0.1 : -0.1); web ? setZoom(nz) : setPz(nz); }
  else if (a === 'theme') themeBtn.click();
  else if (a === 'reload' && web) wv.reload();
  else { if (a === 'search-focus' || a === 'write-log' || a === 'export-csv' || a === 'export-xlsx') document.querySelector('#side button[data-v="pkg"]').click(); document.dispatchEvent(new CustomEvent('menu', { detail: a })); }
});

document.addEventListener('goto-login', () => wv.loadURL('https://desm.doosanenerbility.com'));

// Chạy trong trang DESM (kể cả iframe): nạp từ điển Việt hoá vào thế giới chính của trang.
const { webFrame, ipcRenderer } = require('electron');
try {
  if (/(^|\.)doosanenerbility\.com$/i.test(location.hostname) && ipcRenderer.sendSync('vi:get')) {
    const code = ipcRenderer.sendSync('vi:src');
    if (code) webFrame.executeJavaScript(code);
  }
} catch (_) {}

// Việt hoá giao diện DESM (trích từ JSViet.swift + Translations.swift của app iOS). Chạy trong mọi khung của trang.
(function () {
  var w = window;
  if (w.__desmViLoaded) return; w.__desmViLoaded = true;
  w.__desmCfg = { vi: true, dict: [["Dashboard - DESM", "Bảng điều khiển - DESM"], ["Doosan Enerbility Supply Management", "Quản lý cung ứng Doosan Enerbility"], ["Notice", "Thông báo"], ["Information", "Thông tin"], ["Vessel Map", "Bản đồ tàu"], ["EPC Supply MGMT", "Quản lý cung ứng EPC"], ["Supply MGMT 2.0", "Quản lý cung ứng 2.0"], ["P/L Extractor - MPW", "Trích xuất P/L - MPW"], ["Monthly Progress", "Tiến độ hàng tháng"], ["Shipping Mark", "Ký mã hiệu"], ["Onshore PO", "PO trong nước"], ["Requisitions (POR)", "Yêu cầu mua hàng (POR)"], ["Requisition Manage (POR Manage)", "Quản lý yêu cầu mua hàng (POR)"], ["Purchase Order & Contract", "Đơn đặt hàng & Hợp đồng"], ["Quality Control", "Kiểm soát chất lượng"], ["Shipping Status", "Tình trạng vận chuyển"], ["Site Material MGMT", "Quản lý vật tư công trường"], ["WBS & PKG/Item search", "Tìm WBS & Kiện hàng/Hạng mục"], ["Package", "Kiện hàng"], ["Detail Item", "Hạng mục chi tiết"], ["Material Receiving", "Nhận vật tư"], ["Material Inspection(OPI / OSDM)", "Kiểm tra vật tư (OPI / OSDM)"], ["Special Item Management", "Quản lý hạng mục đặc biệt"], ["Requisition for Stored Items", "Yêu cầu xuất hàng lưu kho"], ["RSI Creation", "Tạo RSI"], ["Outgoing Control", "Kiểm soát xuất kho"], ["RSI Summary", "Tổng hợp RSI"], ["Work In Process Control", "Kiểm soát công việc đang thực hiện"], ["Material Return Form", "Phiếu trả vật tư"], ["MRF Creation", "Tạo MRF"], ["Return Control", "Kiểm soát trả hàng"], ["MRF Summary", "Tổng hợp MRF"], ["Material Map", "Bản đồ vật tư"], ["Site User MGMT", "Quản lý người dùng công trường"], ["Site User Project MGMT", "Quản lý dự án của người dùng công trường"], ["Project Digital Hub", "Trung tâm số dự án"], ["Refresh", "Làm mới"], ["Language", "Ngôn ngữ"], ["Logout", "Đăng xuất"], ["Login", "Đăng nhập"], ["Remove Tab", "Đóng tab"], ["Opensouce License", "Giấy phép mã nguồn mở"], ["Rendering ...", "Đang hiển thị ..."], ["Go Top", "Lên đầu trang"], ["Select Files", "Chọn tệp"], ["Cancel", "Hủy"], ["Title", "Tiêu đề"], ["Message", "Thông báo"], ["Close", "Đóng"], ["Are you sure to comfirm?", "Bạn có chắc chắn muốn xác nhận?"], ["Are you sure to confirm?", "Bạn có chắc chắn muốn xác nhận?"], ["Log", "Nhật ký"], ["Password Change", "Đổi mật khẩu"], ["Current Password", "Mật khẩu hiện tại"], ["New Password", "Mật khẩu mới"], ["New Password Confirmation", "Xác nhận mật khẩu mới"], ["Save", "Lưu"], ["No data found", "Không có dữ liệu"], ["Search", "Tìm kiếm"], ["Reset", "Đặt lại"], ["Project", "Dự án"], ["Shipment No.", "Số lô hàng"], ["All", "Tất cả"], ["Packing List No.", "Số Packing List"], ["Package No.", "Số kiện hàng"], ["Description", "Mô tả"], ["Location", "Vị trí"], ["All Exists", "Tất cả đã có"], ["All Not Exists", "Tất cả chưa có"], ["Vendor", "Nhà cung cấp"], ["Remark", "Ghi chú"], ["MRR Received", "Đã nhận MRR"], ["Yes", "Có"], ["No", "Không"], ["Received", "Đã nhận"], ["Customs", "Hải quan"], ["Material Confirm", "Xác nhận vật tư"], ["MRR Result", "Kết quả MRR"], ["Good", "Tốt"], ["Defect", "Lỗi"], ["MRR Received Date", "Ngày nhận MRR"], ["Received Date", "Ngày nhận"], ["MIR Category", "Phân loại MIR"], ["Electrical", "Điện"], ["Mechanical", "Cơ khí"], ["I&C", "Đo lường & Điều khiển"], ["Civil", "Xây dựng"], ["Commissioning", "Chạy thử"], ["Etc", "Khác"], ["Package Status", "Trạng thái kiện hàng"], ["Open", "Mở"], ["Partially", "Một phần"], ["Detail Item Creation", "Tạo hạng mục chi tiết"], ["Material Cancel", "Hủy vật tư"], ["Location Delete", "Xóa vị trí"], ["Location Update", "Cập nhật vị trí"], ["Received Date Update", "Cập nhật ngày nhận"], ["QR Code", "Mã QR"], ["Area", "Khu vực"], ["Material", "Vật tư"], ["Confirm", "Xác nhận"], ["Cancel Date", "Ngày hủy"], ["Canceled By", "Người hủy"], ["Invoice No", "Số hóa đơn"], ["Closed", "Đã đóng"], ["Description of Goods", "Mô tả hàng hóa"], ["Specification", "Quy cách"], ["Packing Style", "Kiểu đóng gói"], ["Measurement", "Kích thước"], ["Net Weight", "Trọng lượng tịnh"], ["Gross Weight", "Trọng lượng cả bì"], ["Excel Remark", "Ghi chú Excel"], ["Visual Check", "Kiểm tra ngoại quan"], ["Last Outgoing Date", "Ngày xuất gần nhất"], ["QTY", "SL"], ["(UNIT, spare part..)", "(Đơn vị, phụ tùng..)"], ["Location Last Updated Date", "Ngày cập nhật vị trí gần nhất"], ["Location Last Updated By", "Người cập nhật vị trí gần nhất"], ["Shortage", "Thiếu"], ["Overage", "Thừa"], ["Damage", "Hư hỏng"], ["Missing", "Mất"], ["Style:", "Kiểu:"], ["Size:", "Cỡ:"], ["Normal", "Bình thường"], ["Scale:", "Tỉ lệ:"], ["Add", "Thêm"], ["Delete", "Xóa"], ["Edit", "Sửa"], ["Update", "Cập nhật"], ["Create", "Tạo mới"], ["Upload", "Tải lên"], ["Download", "Tải xuống"], ["Export", "Xuất file"], ["Import", "Nhập file"], ["Print", "In"], ["Submit", "Gửi"], ["Approve", "Phê duyệt"], ["Reject", "Từ chối"], ["Apply", "Áp dụng"], ["Select", "Chọn"], ["Select All", "Chọn tất cả"], ["Status", "Trạng thái"], ["Date", "Ngày"], ["From", "Từ"], ["To", "Đến"], ["Remarks", "Ghi chú"], ["Total", "Tổng"], ["Unit", "Đơn vị"], ["Name", "Tên"], ["User", "Người dùng"], ["Password", "Mật khẩu"], ["Error", "Lỗi"], ["Success", "Thành công"], ["Warning", "Cảnh báo"], ["Loading...", "Đang tải..."], ["Please select", "Vui lòng chọn"], ["Saved successfully.", "Đã lưu thành công."], ["Deleted successfully.", "Đã xóa thành công."], ["Do you want to save?", "Bạn có muốn lưu không?"], ["Do you want to delete?", "Bạn có muốn xóa không?"]], custom: [], scope: false };
  function allowed(doc) { return true; }

          // ===== Dịch giao diện sang tiếng Việt (chỉ khi bật trong Cài đặt hoặc chọn "Tiếng Việt" ở ô Language) =====
          function viNorm(s) { return String(s).replace(/[\u200b\s]+/g, ' ').trim().toLowerCase(); }
          function viMap() {
            var c = w.__desmCfg, sig = (c.dict ? c.dict.length : 0) + ':' + (c.custom ? JSON.stringify(c.custom) : '');
            if (w.__desmViSig === sig && w.__desmViM) return w.__desmViM;
            var m = {};
            (c.dict || []).concat(c.custom || []).forEach(function(p) { if (p && p.length > 1) m[viNorm(p[0])] = p[1]; });
            w.__desmViSig = sig; w.__desmViM = m; return m;
          }
          function viLookup(str) {
            var core = String(str).replace(/^[\s\u200b]+|[\s\u200b]+$/g, '');
            if (!core) return null;
            var v = viMap()[viNorm(core)];
            if (v === undefined) return null;
            var letters = core.replace(/[^A-Za-z]/g, '');
            if (letters.length >= 3 && core === core.toUpperCase()) v = v.toUpperCase();
            if (v === core) return null;
            var lead = str.match(/^[\s\u200b]*/)[0], trail = str.match(/[\s\u200b]*$/)[0];
            return lead + v + trail;
          }
          function viMiss(core) {
            try {
              if (!/^[A-Za-z][A-Za-z &\/\-\.\(\),:'’%]{1,70}$/.test(core)) return;
              var t = w.top; t.__desmMiss = t.__desmMiss || {}; t.__desmMiss[core] = 1;
            } catch (e) {}
          }
          function viText(n) {
            var p = n.parentNode; if (!p || p.nodeType !== 1) return;
            var tg = p.tagName; if (tg === 'SCRIPT' || tg === 'STYLE' || tg === 'TEXTAREA') return;
            if (p.closest && p.closest('#desmCards, #desmDetail, .desm-sub')) return;
            var v = n.nodeValue; if (!v || !/[A-Za-z]/.test(v)) return;
            var r = viLookup(v);
            if (r !== null) { if (r !== v) n.nodeValue = r; return; }
            var cl = (p.getAttribute && p.getAttribute('class')) || '';
            if (!/gridText|gridLinkText|TMCellBase/.test(cl)) viMiss(v.replace(/[\u200b\s]+/g, ' ').trim());
          }
          var VI_ATTR = ['placeholder', 'title', 'alt'];
          function viAttrs(el) {
            if (!el || el.nodeType !== 1) return;
            VI_ATTR.forEach(function(a) {
              var v = el.getAttribute(a); if (!v) return;
              var r = viLookup(v); if (r !== null && r !== v) el.setAttribute(a, r);
            });
            if (el.tagName === 'INPUT' && /^(button|submit|reset)$/i.test(el.type || '')) {
              var r2 = viLookup(el.value || ''); if (r2 !== null && r2 !== el.value) el.value = r2;
            }
          }
          function viWalk(root) {
            if (!root) return;
            if (root.nodeType === 3) { viText(root); return; }
            var doc = root.nodeType === 9 ? root : root.ownerDocument;
            var base = root.nodeType === 9 ? root.documentElement : root;
            if (!doc || !base || base.nodeType !== 1) return;
            try { if (base.closest && base.closest('.dodo-msgs')) return; } catch (e) {}   // không dịch câu trả lời của Dodo
            viAttrs(base);
            var els = base.querySelectorAll('[placeholder],[title],[alt],input[type=button],input[type=submit],input[type=reset]');
            for (var i = 0; i < els.length; i++) viAttrs(els[i]);
            var tw = doc.createTreeWalker(base, 4, null), n;
            while ((n = tw.nextNode())) { if (n.parentNode && n.parentNode.closest && n.parentNode.closest('.dodo-msgs')) continue; viText(n); }
          }
          function viPost(lang) {
            try { w.webkit.messageHandlers.desmLang.postMessage({ lang: lang }); } catch (e) {}
          }
          // Thêm mục "Tiếng Việt" vào ô Language của DESM (máy chủ chỉ có en/ko/ru nên mục này do app xử lý)
          function viLangSel(doc) {
            var sel = doc.getElementById('selLang'); if (!sel || !allowed(doc)) return;
            var c = w.__desmCfg;
            if (!sel.querySelector('option[value="vi"]')) {
              var o = doc.createElement('option'); o.value = 'vi'; o.textContent = 'Tiếng Việt'; sel.appendChild(o);
            }
            if (doc.activeElement !== sel) {
              if (c.vi && sel.value !== 'vi') sel.value = 'vi';
              else if (!c.vi && sel.value === 'vi') sel.value = '';
            }
            if (doc.__desmLangHook) return;
            doc.__desmLangHook = true;
            doc.addEventListener('change', function(e) {
              var t = e.target;
              if (!t || t.id !== 'selLang' || doc.__desmBypass) return;
              if (t.value === 'vi') {
                e.stopImmediatePropagation(); e.stopPropagation();
                w.__desmCfg.vi = true; viPost('vi');
                // Cho trang tải ở ngôn ngữ gốc English (từ điển dịch từ English sang Việt)
                doc.__desmBypass = true; t.value = 'en';
                try { t.dispatchEvent(new Event('change', { bubbles: true })); } catch (x) {}
                doc.__desmBypass = false;
                setTimeout(function() { viLangSel(doc); }, 300);
                setTimeout(function() { viLangSel(doc); }, 1500);
              } else if (t.value) {
                w.__desmCfg.vi = false; viPost('site');
              }
            }, true);
          }
          function viInit() {
            if (w.__desmViInit) return; w.__desmViInit = true;
            ['alert', 'confirm', 'prompt'].forEach(function(nm) {
              var o = w[nm]; if (typeof o !== 'function' || o.__desmVi) return;
              var f = function(msg) {
                var a = [].slice.call(arguments);
                try {
                  if (w.__desmCfg.vi && typeof a[0] === 'string') {
                    var r = viLookup(a[0]);
                    if (r === null) {
                      var ch = false, parts = a[0].split('\n').map(function(l) { var x = viLookup(l); if (x !== null) { ch = true; return x; } return l; });
                      if (ch) r = parts.join('\n');
                    }
                    if (r !== null) a[0] = r;
                  }
                } catch (e) {}
                return o.apply(w, a);
              };
              f.__desmVi = 1; w[nm] = f;
            });
            var pend = [], queued = false;
            function flush() {
              queued = false;
              if (!w.__desmCfg.vi) { pend = []; return; }
              var list = pend; pend = [];
              try {
                if (list.length > 400) { viWalk(document); }
                else list.forEach(function(x) { if (x.t === 'a') viAttrs(x.n); else if (x.n.isConnected !== false) viWalk(x.n); });
                viLangSel(document);
              } catch (e) {}
            }
            function push(t, n) {
              pend.push({ t: t, n: n });
              if (!queued) { queued = true; (w.requestAnimationFrame || w.setTimeout)(flush); }
            }
            try {
              new MutationObserver(function(ms) {
                if (!w.__desmCfg.vi) { try { viLangSel(document); } catch (e) {} return; }
                for (var i = 0; i < ms.length; i++) {
                  var m = ms[i];
                  if (m.type === 'childList') { for (var j = 0; j < m.addedNodes.length; j++) push('w', m.addedNodes[j]); }
                  else if (m.type === 'characterData') push('w', m.target);
                  else if (m.type === 'attributes') push('a', m.target);
                }
              }).observe(document.documentElement, { childList: true, subtree: true, characterData: true,
                attributes: true, attributeFilter: ['placeholder', 'title', 'alt', 'value'] });
            } catch (e) {}
          }
          function viApply(doc) {
            var c = w.__desmCfg;
            try { if (allowed(doc)) viLangSel(doc); } catch (e) {}
            if (!c.vi || !allowed(doc)) return;
            viInit();
            try { viWalk(doc); } catch (e) {}
          }
        
  viLangSel = function () {};   // ô Language do app iOS xử lý, bản PC bỏ qua
  function go() { try { viApply(document); } catch (e) {} }
  go(); document.addEventListener('DOMContentLoaded', go);
})();

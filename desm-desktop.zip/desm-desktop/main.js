const { app, BrowserWindow, Menu, session, shell, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const PART = 'persist:desm';
const DAY30 = 30 * 24 * 3600;
const ORIGIN = 'https://desm.doosanenerbility.com';
let win = null;

// Gọi API DESM bằng đúng phiên đăng nhập của webview (cookie chung partition)
ipcMain.handle('desm:post', async (_e, p, form) => {
  try {
    if (!/^\/[A-Za-z0-9_\/.\-]+\.do$/.test(String(p))) return { ok: false, error: 'path' };
    const r = await session.fromPartition(PART).fetch(ORIGIN + p, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: new URLSearchParams(form || {}).toString()
    });
    const t = await r.text();
    try { return { ok: r.ok, status: r.status, json: JSON.parse(t) }; }
    catch (_) { return { ok: false, status: r.status, error: (/login/i.test(r.url) || /<html/i.test(t)) ? 'login' : 'parse', text: t.slice(0, 300) }; }
  } catch (e) { return { ok: false, error: String(e) }; }
});

// Ảnh bản đồ vị trí (cần cookie đăng nhập) -> trả về data URL
ipcMain.handle('desm:img', async (_e, p) => {
  try {
    const u = new URL(String(p), ORIGIN);
    if (u.protocol !== 'https:' || !/(^|\.)doosanenerbility\.com$/i.test(u.hostname)) return { ok: false, error: 'Địa chỉ ảnh không hợp lệ' };
    const r = await session.fromPartition(PART).fetch(u.href, { credentials: 'include', headers: { Referer: ORIGIN + '/' } });
    if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
    const ct = (r.headers.get('content-type') || '').split(';')[0];
    if (!/^image\//i.test(ct)) return { ok: false, error: 'Không phải ảnh (có thể chưa đăng nhập)' };
    return { ok: true, data: 'data:' + ct + ';base64,' + Buffer.from(await r.arrayBuffer()).toString('base64') };
  } catch (e) { return { ok: false, error: String(e) }; }
});

// Preload bị sandbox (Electron >= 20) nên không đọc được file: nguồn script được main phục vụ qua IPC
let viOn = true;
const src = f => fs.readFileSync(path.join(__dirname, f), 'utf8');
ipcMain.handle('dodo:src', () => src('dodo.js'));
ipcMain.handle('webpreload:url', () => pathToFileURL(path.join(__dirname, 'preload-web.js')).href);
ipcMain.handle('vi:set', (_e, on) => { viOn = !!on; return viOn; });
ipcMain.on('vi:get', e => { e.returnValue = viOn; });
ipcMain.on('vi:src', e => { try { e.returnValue = src('vi.js'); } catch (_) { e.returnValue = ''; } });

function keepSessionCookies() {
  // Cookie phiên (không có hạn) bị xoá khi tắt app -> gia hạn 30 ngày để giữ đăng nhập
  const ses = session.fromPartition(PART);
  ses.cookies.on('changed', (_e, c, _cause, removed) => {
    if (removed || !c.session) return;
    const url = (c.secure ? 'https://' : 'http://') + c.domain.replace(/^\./, '') + c.path;
    ses.cookies.set({ url, name: c.name, value: c.value, domain: c.domain, path: c.path,
      secure: c.secure, httpOnly: c.httpOnly, expirationDate: Date.now() / 1000 + DAY30 }).catch(() => {});
  });
}

// Nhớ kích thước/vị trí cửa sổ giữa các lần mở
const stateFile = () => path.join(app.getPath('userData'), 'window-state.json');
const loadState = () => { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch (_) { return {}; } };
function saveState() {
  try { if (!win) return; const b = win.getNormalBounds(); fs.writeFileSync(stateFile(), JSON.stringify({ ...b, max: win.isMaximized() })); } catch (_) {}
}

const send = a => () => { if (win) win.webContents.send('menu', a); };
function buildMenu() {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Tệp', submenu: [
      { label: 'Tải lại / Search', accelerator: 'F5', click: send('reload') },
      { label: 'Xuất Excel (.xlsx)', accelerator: 'CmdOrCtrl+E', click: send('export-xlsx') },
      { label: 'Xuất CSV', accelerator: 'CmdOrCtrl+Shift+E', click: send('export-csv') },
      { type: 'separator' }, { label: 'Thoát', role: 'quit' }] },
    { label: 'Xem', submenu: [
      { label: 'Package', accelerator: 'CmdOrCtrl+1', click: send('view-pkg') },
      { label: 'Trình duyệt DESM', accelerator: 'CmdOrCtrl+2', click: send('view-web') },
      { label: 'Tìm nhanh Package No', accelerator: 'CmdOrCtrl+K', click: send('search-focus') },
      { type: 'separator' },
      { label: 'Phóng to', accelerator: 'CmdOrCtrl+Plus', click: send('zoom-in') },
      { label: 'Thu nhỏ', accelerator: 'CmdOrCtrl+-', click: send('zoom-out') },
      { label: 'Kích thước gốc', accelerator: 'CmdOrCtrl+0', click: send('zoom-reset') },
      { type: 'separator' },
      { label: 'Chế độ sáng/tối', accelerator: 'CmdOrCtrl+D', click: send('theme') },
      { label: 'Toàn màn hình', role: 'togglefullscreen' }] },
    { label: 'Công cụ', submenu: [
      { label: 'Nhật ký thao tác ghi', accelerator: 'CmdOrCtrl+L', click: send('write-log') },
      { label: 'Công cụ nhà phát triển', accelerator: 'CmdOrCtrl+Shift+I', click: () => win && win.webContents.toggleDevTools() }] },
    { label: 'Trợ giúp', submenu: [
      { label: 'Giới thiệu DESM Desktop', click: () => dialog.showMessageBox(win, { type: 'info', title: 'DESM Desktop', message: 'DESM Desktop ' + app.getVersion(), detail: 'Bản PC của DESM Mobile (Electron). Chưa ký số.' }) }] }
  ]));
}

function createWindow() {
  const st = loadState();
  win = new BrowserWindow({
    width: st.width || 1360, height: st.height || 840, x: st.x, y: st.y, minWidth: 1000, minHeight: 640,
    title: 'DESM Desktop', icon: path.join(__dirname, 'build', 'icon.png'), show: false, backgroundColor: '#f4f6fa',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true }
  });
  if (st.max) win.maximize();
  win.once('ready-to-show', () => win.show());
  win.on('close', saveState);
  win.on('closed', () => { win = null; });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => { keepSessionCookies(); buildMenu(); createWindow(); });
  app.on('window-all-closed', () => app.quit());
}

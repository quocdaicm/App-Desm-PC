const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desm', {
  getDodo: () => ipcRenderer.invoke('dodo:src'),
  webPreloadUrl: () => ipcRenderer.invoke('webpreload:url'),
  setVi: on => ipcRenderer.invoke('vi:set', on),
  post: (p, form) => ipcRenderer.invoke('desm:post', p, form),
  img: path => ipcRenderer.invoke('desm:img', path),
  onMenu: cb => ipcRenderer.on('menu', (_e, a) => cb(a))
});
